package com.example.btkeyboard

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** label=通常表示, shifted=Shift時表示, code=HID Usage ID */
class K(
    val label: String,
    val code: Int,
    val shifted: String? = null,
    val w: Float = 1f,
    val isShift: Boolean = false,
    val special: Boolean = false
)

private fun letters(s: String) = s.map { K(it.toString(), 0x04 + (it - 'a'), it.uppercase()) }

private val NUM_SHIFT = listOf("!", "\"", "#", "$", "%", "&", "'", "(", ")", " ")

// JIS配列(見た目はGboardのQWERTYに近い並び)
private val ROWS: List<List<K>> = listOf(
    listOf(K("半/全", 0x35, special = true)) +
        "1234567890".mapIndexed { i, c ->
            K(c.toString(), if (c == '0') 0x27 else 0x1E + i, NUM_SHIFT[i])
        } +
        listOf(
            K("-", 0x2D, "="), K("^", 0x2E, "~"), K("¥", 0x89, "|"),
            K("⌫", 0x2A, w = 1.5f, special = true)
        ),
    listOf(K("Tab", 0x2B, w = 2f, special = true)) + letters("qwertyuiop") +
        listOf(K("@", 0x2F, "`"), K("[", 0x30, "{"), K("Del", 0x4C, w = 1.5f, special = true)),
    listOf(K("Esc", 0x29, w = 1.75f, special = true)) + letters("asdfghjkl") +
        listOf(
            K(";", 0x33, "+"), K(":", 0x34, "*"), K("]", 0x32, "}"),
            K("Enter", 0x28, w = 1.75f, special = true)
        ),
    listOf(K("⇧", 0, w = 2.25f, isShift = true, special = true)) + letters("zxcvbnm") +
        listOf(
            K(",", 0x36, "<"), K(".", 0x37, ">"), K("/", 0x38, "?"), K("ろ", 0x87, "_"),
            K("⇧", 0, w = 2.25f, isShift = true, special = true)
        ),
    listOf(
        K("英数", 0x91, w = 1.5f, special = true),
        K("無変換", 0x8B, w = 1.5f, special = true),
        K("Space", 0x2C, w = 5.5f),
        K("変換", 0x8A, w = 1.5f, special = true),
        K("かな", 0x90, w = 1.5f, special = true),
        K("←", 0x50, special = true), K("↓", 0x51, special = true),
        K("↑", 0x52, special = true), K("→", 0x4F, special = true)
    )
)

@SuppressLint("MissingPermission", "ClickableViewAccessibility")
class MainActivity : Activity() {
    private lateinit var hid: HidManager
    private lateinit var status: TextView
    private val keyViews = ArrayList<Pair<TextView, K>>()
    private var shift = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val lp = window.attributes
        lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        window.attributes = lp

        hid = HidManager(this) { msg -> runOnUiThread { status.text = msg } }
        setContentView(buildUi())

        if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
        ) hid.start()
        else requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) hid.start()
        else status.text = "Bluetoothの権限が必要です"
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.insetsController?.apply {
            hide(WindowInsets.Type.systemBars())
            systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onPause() {
        super.onPause()
        shift = false
        hid.releaseAll()
        refresh()
    }

    override fun onDestroy() {
        hid.stop()
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        status = TextView(this).apply {
            setTextColor(Color.LTGRAY); textSize = 12f; text = "起動中…"
        }
        bar.addView(status, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        bar.addView(smallButton("検出可能にする") {
            startActivity(
                Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                    .putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
            )
        })
        bar.addView(smallButton("接続先") { pickDevice() })
        root.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, dp(40)))

        ROWS.forEach { row ->
            val r = LinearLayout(this)
            row.forEach { k ->
                r.addView(makeKey(k), LinearLayout.LayoutParams(0, MATCH_PARENT, k.w).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                })
            }
            root.addView(r, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        }
        return root
    }

    private fun smallButton(t: String, f: () -> Unit) = Button(this).apply {
        text = t; textSize = 12f; isAllCaps = false
        minHeight = 0; minimumHeight = 0
        setOnClickListener { f() }
    }

    private fun makeKey(k: K): TextView {
        val t = TextView(this).apply {
            text = k.label
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = if (k.label.length > 1) 13f else 18f
        }
        paint(t, k, false)
        t.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { paint(t, k, true); onDown(k) }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { paint(t, k, false); onUp(k) }
            }
            true
        }
        keyViews.add(t to k)
        return t
    }

    private fun paint(t: TextView, k: K, pressed: Boolean) {
        val c = when {
            pressed -> 0xFF666666.toInt()
            k.isShift && shift -> 0xFF3B6FD4.toInt()
            k.special -> 0xFF1F1F1F.toInt()
            else -> 0xFF333333.toInt()
        }
        t.background = GradientDrawable().apply { setColor(c); cornerRadius = dp(6).toFloat() }
    }

    private fun refresh() {
        keyViews.forEach { (t, k) ->
            t.text = if (shift && k.shifted != null) k.shifted else k.label
            paint(t, k, false)
        }
    }

    private fun onDown(k: K) {
        if (k.isShift) {            // Shiftは次の1キーだけ有効(ワンショット)
            shift = !shift
            hid.modifiers = if (shift) 0x02 else 0
            refresh()
            return
        }
        hid.keyDown(k.code)
    }

    private fun onUp(k: K) {
        if (k.isShift) return
        if (shift) { shift = false; hid.modifiers = 0; refresh() }
        hid.keyUp(k.code)
    }

    private fun pickDevice() {
        val devs = hid.bonded()
        if (devs.isEmpty()) {
            status.text = "先に「検出可能にする」→ iPhone/iPad側でペアリングしてください"
            return
        }
        AlertDialog.Builder(this)
            .setTitle("接続先")
            .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, i ->
                hid.connect(devs[i])
            }
            .show()
    }
}
