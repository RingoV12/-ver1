package com.example.btkeyboard

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context

/** スマホをBluetooth HIDキーボードとして振る舞わせる。 */
@SuppressLint("MissingPermission")
class HidManager(private val ctx: Context, private val onStatus: (String) -> Unit) {

    private val adapter: BluetoothAdapter? =
        ctx.getSystemService(BluetoothManager::class.java)?.adapter
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private val pressed = LinkedHashSet<Int>()

    /** 修飾キー(0x02 = 左Shift) */
    var modifiers = 0

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            onStatus(if (registered) "準備完了。接続先を選んでください" else "HID未登録")
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> {
                    host = device
                    onStatus("接続中: ${device?.name ?: device?.address}")
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    if (host == device) host = null
                    onStatus("切断されました")
                }
            }
        }
    }

    private val listener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            val h = proxy as BluetoothHidDevice
            hid = h
            val sdp = BluetoothHidDeviceAppSdpSettings(
                "JIS Keyboard", "Android BT Keyboard", "Personal",
                BluetoothHidDevice.SUBCLASS1_KEYBOARD, DESCRIPTOR
            )
            if (!h.registerApp(sdp, null, null, ctx.mainExecutor, callback)) {
                onStatus("HIDの登録に失敗しました")
            }
        }

        override fun onServiceDisconnected(profile: Int) {
            hid = null
        }
    }

    fun start() {
        val ok = adapter?.getProfileProxy(ctx, listener, BluetoothProfile.HID_DEVICE) == true
        if (!ok) onStatus("この端末はBluetooth HIDデバイスに未対応です")
    }

    fun stop() {
        hid?.unregisterApp()
        adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid)
        hid = null
    }

    fun bonded(): List<BluetoothDevice> = adapter?.bondedDevices?.toList() ?: emptyList()

    fun connect(device: BluetoothDevice) {
        onStatus("接続中…")
        hid?.connect(device)
    }

    fun keyDown(code: Int) {
        pressed.add(code)
        send()
    }

    fun keyUp(code: Int) {
        pressed.remove(code)
        send()
    }

    fun releaseAll() {
        pressed.clear()
        modifiers = 0
        send()
    }

    private fun send() {
        val h = hid ?: return
        val d = host ?: return
        val r = ByteArray(8)
        r[0] = modifiers.toByte()
        pressed.take(6).forEachIndexed { i, c -> r[2 + i] = c.toByte() }
        h.sendReport(d, 1, r)
    }

    companion object {
        // Report ID 1 / 標準キーボード。JISキー(0x87-0x91)も送れるよう Usage Max = 0xFF
        private val DESCRIPTOR = intArrayOf(
            0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
            0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01,
            0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
            0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
            0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x95, 0x05, 0x75, 0x01, 0x91, 0x02,
            0x95, 0x01, 0x75, 0x03, 0x91, 0x01,
            0x05, 0x07, 0x19, 0x00, 0x29, 0xFF, 0x15, 0x00, 0x26, 0xFF, 0x00,
            0x95, 0x06, 0x75, 0x08, 0x81, 0x00,
            0xC0
        ).map { it.toByte() }.toByteArray()
    }
}
